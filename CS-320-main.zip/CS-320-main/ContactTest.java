package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void constructorAcceptsValidInput() {
        assertDoesNotThrow(() -> {
            new Contact("12345", "Alice", "Brown", "0123456789", "123 Maple St");
        });
    }

    @Test
    void constructorRejectsNullId() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact(null, "Alice", "Brown", "0123456789", "123 Maple St"));
    }

    @Test
    void constructorRejectsLongId() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("12345678901", "Alice", "Brown", "0123456789", "123 Maple St"));
    }

    @Test
    void constructorRejectsNullFirstName() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("123", null, "Brown", "0123456789", "123 Maple St"));
    }

    @Test
    void constructorRejectsLongFirstName() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("123", "VeryLongName", "Brown", "0123456789", "123 Maple St"));
    }

    @Test
    void constructorRejectsInvalidPhone() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("123", "Alice", "Brown", "12345", "123 Maple St"));
    }

    @Test
    void settersUpdateValidFields() {
        Contact c = new Contact("abc", "A", "B", "0123456789", "Addr");
        assertDoesNotThrow(() -> {
            c.setFirstName("Bob");
            c.setLastName("Smith");
            c.setPhone("0987654321");
            c.setAddress("456 Oak Avenue");
        });
        assertEquals("Bob", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Oak Avenue", c.getAddress());
    }

    @Test
    void settersRejectInvalidValues() {
        Contact c = new Contact("abc", "A", "B", "0123456789", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ThisNameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("notdigits"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("This address is way too long to be valid because it exceeds thirty characters"));
    }
}
