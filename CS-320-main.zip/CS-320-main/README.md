# CS-320 Portfolio Submission

This repository contains selected artifacts from **CS-320: Software Testing and Automation**.  
These projects demonstrate my ability to write unit tests, apply software testing strategies, and ensure software quality.

---

## Project One: Contact Service

Files included:
- `Contact.java`
- `ContactService.java`
- `ContactTest.java`
- `ContactServiceTest.java`

These files show how I created a simple contact management service and applied unit tests to verify its functionality.

---

## Project Two: Summary and Reflections Report

File included:
- `7-2 Project Two Submission.docx`
This report explains my approach to testing, automation, and quality assurance throughout the course.

---

## Reflection

### How can I ensure that my code, program, or software is functional and secure?
I ensure functionality by writing and running unit tests that verify requirements and uncover errors early. Automated testing helps continuously validate the program as changes are made. For security, I follow good practices such as input validation and careful handling of data to reduce vulnerabilities.

### How do I interpret user needs and incorporate them into a program?
I interpret user needs by reviewing requirements and translating them into features that solve real problems for the user. By focusing on user stories and acceptance criteria, I can make sure the program delivers the intended value.

### How do I approach designing software?
I approach design by breaking down the problem into smaller parts and creating models, such as UML diagrams, to plan the structure of the system. This helps me build software that is organized, easy to maintain, and testable while still meeting functional goals.
