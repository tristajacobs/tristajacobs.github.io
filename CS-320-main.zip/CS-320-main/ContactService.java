package com.contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    // Adds a new contact; throws if the ID already exists
    public void addContact(Contact c) {
        if (c == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        String id = c.getId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("ID already exists: " + id);
        }
        contacts.put(id, c);
    }

    // Deletes a contact by ID (no error if missing)
    public void deleteContact(String id) {
        contacts.remove(id);
    }

    // Updates the fields of an existing contact
    public void updateContact(String id, String firstName,
                              String lastName, String phone,
                              String address) {
        Contact c = contacts.get(id);
        if (c == null) {
            throw new IllegalArgumentException("Contact not found: " + id);
        }
        c.setFirstName(firstName);
        c.setLastName(lastName);
        c.setPhone(phone);
        c.setAddress(address);
    }
}