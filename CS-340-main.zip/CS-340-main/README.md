# CS-340 8-2 Journal: Portfolio Item

## How do you write programs that are maintainable, readable, and adaptable?
I write programs by keeping the code modular, well-formatted, and documented. In Project One, I built the CRUD Python module with separate methods for create, read, update, and delete. This made the code easy to reuse in Project Two when connecting the dashboard widgets to the database. The advantage of this approach was that I did not have to rewrite database logic — I only needed to call the existing methods. In the future, this CRUD module could be reused in other projects that need database access, such as mobile apps or game development projects.

## How do you approach a problem as a computer scientist?
I break down requirements into small, testable steps. For Grazioso Salvare, I first ensured the database was imported and authenticated correctly, then connected the dashboard to the CRUD module. Compared to earlier courses, this project required more planning around user needs and database structure. In the future, I would continue using modular design, authentication workflows, and step-by-step testing to meet client requests for databases or dashboards.

## What do computer scientists do, and why does it matter?
Computer scientists solve problems by designing systems that are efficient, reliable, and user-focused. My work on the Grazioso Salvare project helps the company manage animal data more effectively, which supports their mission of training rescue dogs. By building a dashboard connected to a database, I made it easier for them to filter, search, and visualize the information they need. This kind of work matters because it allows organizations to use technology to achieve their goals faster and with fewer errors.
