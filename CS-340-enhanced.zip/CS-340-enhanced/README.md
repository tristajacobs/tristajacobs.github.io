# CS-340 Project Two – Grazioso Salvare Dashboard  
**Student:** Trista Jacobs

## Overview
This dashboard was built to help Grazioso Salvare identify dogs suitable for different types of rescue training. It connects to a MongoDB database using a custom CRUD module and displays animal data in a clean, interactive layout. The table, chart, and map all update based on the selected filter.

## Features
- Interactive radio filters:
  - Water Rescue
  - Mountain or Wilderness Rescue
  - Disaster or Individual Tracking
  - Reset (shows all data)
- Data table with full animal details
- Pie chart showing breed distribution
- Map showing location of selected animal
- Grazioso Salvare logo and student name at the top

## Screenshot Summary
Screenshots are included separately to demonstrate functionality and rubric alignment. Each one shows a different filter state and confirms that the dashboard updates correctly.

1. **Starting State – Reset Filter**  
   - Shows full dataset, chart with all breeds, and map centered  
   - Filename: `Reset.png`

2. **Water Rescue Filter**  
   - Shows only Labrador Retriever Mixes and other water breeds  
   - Chart shows 100% Labrador Retriever Mix  
   - Filename: `Water Rescue.png`

3. **Mountain Rescue Filter**  
   - Shows breeds like Husky, Rottweiler, etc.  
   - Chart and map update based on filtered data  
   - Filename: `Mountain or Wilderness Rescue.png`

4. **Disaster Tracking Filter**  
   - Shows Bloodhound, German Shepherd, Rottweiler, etc.  
   - Chart and map reflect filtered results  
   - Filename: `Disaster or Individual Tracking.png`

5. **Branding – Logo and Student Name**  
   - Grazioso Salvare logo and “Dashboard by Trista Jacobs” visible at the top  
   - Included in one or more of the above screenshots

## How to Run
1. Open `ProjectTwoDashboard.ipynb` in JupyterLab.
2. Make sure MongoDB is running (no authentication required).
3. Run all cells from the top.
4. The dashboard will launch in a new tab with full interactivity.

## Challenges
One challenge I encountered was ensuring that all dashboard components updated together when a filter was applied. At first, the table, chart, and map did not stay in sync. I solved this by linking the radio input to each callback function so that all components shared the same filtered dataset. This ensured the dashboard remained consistent and user-friendly.

## Notes
- The CRUD module (`CRUD_Python_Module.py`) handles all database reads.
- No login is required — MongoDB access is open in this environment.
- All filters and visuals were validated using the screenshots listed above.