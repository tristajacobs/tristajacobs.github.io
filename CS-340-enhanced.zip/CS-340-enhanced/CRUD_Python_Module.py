"""
Enhanced CRUD Module for CS-340
Author: Trista Jacobs
Date: October 2026

Enhancements:
- Input validation for all CRUD operations
- Centralized error handling
- Logging for auditing and debugging
- Defensive programming to prevent crashes
- Secure MongoDB operations (no unsafe queries)
- Clear documentation for each method
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError, ConnectionFailure
import logging

# -----------------------------
# Logging Setup
# -----------------------------
logging.basicConfig(
    filename="crud_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, host="localhost", port=27017, db="aac", collection="animals"):
        """Initialize database connection with error handling."""
        try:
            self.client = MongoClient(host, port, serverSelectionTimeoutMS=3000)
            self.client.server_info()  # Force connection test
            self.database = self.client[db]
            self.collection = self.database[collection]
            logging.info("Connected to MongoDB successfully.")
        except ConnectionFailure:
            logging.error("Failed to connect to MongoDB.")
            raise Exception("Database connection failed.")

    # -----------------------------
    # CREATE
    # -----------------------------
    def create(self, data):
        """Insert a new document into the collection."""
        if not isinstance(data, dict) or not data:
            raise ValueError("Invalid data. Must be a non-empty dictionary.")

        try:
            result = self.collection.insert_one(data)
            logging.info(f"Inserted document with ID: {result.inserted_id}")
            return result.acknowledged
        except PyMongoError as e:
            logging.error(f"Create operation failed: {e}")
            return False

    # -----------------------------
    # READ
    # -----------------------------
    def read(self, query):
        """Retrieve documents matching the query."""
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        try:
            results = list(self.collection.find(query))
            logging.info(f"Read operation returned {len(results)} result(s).")
            return results
        except PyMongoError as e:
            logging.error(f"Read operation failed: {e}")
            return []

    # -----------------------------
    # UPDATE
    # -----------------------------
    def update(self, query, new_values):
        """Update documents matching the query."""
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            raise ValueError("Query and update values must be dictionaries.")

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            logging.info(f"Updated {result.modified_count} document(s).")
            return result.modified_count
        except PyMongoError as e:
            logging.error(f"Update operation failed: {e}")
            return 0

    # -----------------------------
    # DELETE
    # -----------------------------
    def delete(self, query):
        """Delete documents matching the query."""
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        try:
            result = self.collection.delete_many(query)
            logging.info(f"Deleted {result.deleted_count} document(s).")
            return result.deleted_count
        except PyMongoError as e:
            logging.error(f"Delete operation failed: {e}")
            return 0
