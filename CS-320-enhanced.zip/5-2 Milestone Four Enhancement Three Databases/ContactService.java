package com.contactservice;

import java.util.HashMap;
import java.util.Map;

// ContactService class
// Manages contacts and provides CRUD operations.
public class ContactService {

    private Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact c) {
        if (c == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        String id = c.getId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("ID already exists: " + id);
        }

        contacts.put(id, c);
    }

    public void deleteContact(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("ID cannot be null or empty");
        }
        contacts.remove(id);
    }

    public void updateContact(String id, String firstName, String lastName, String phone, String address) {

        Contact c = contacts.get(id);
        if (c == null) {
            throw new IllegalArgumentException("Contact not found: " + id);
        }

        if (firstName == null || firstName.isEmpty()) {
            throw new IllegalArgumentException("Invalid firstName");
        }
        if (lastName == null || lastName.isEmpty()) {
            throw new IllegalArgumentException("Invalid lastName");
        }
        if (phone == null || phone.isEmpty()) {
            throw new IllegalArgumentException("Invalid phone");
        }
        if (address == null || address.isEmpty()) {
            throw new IllegalArgumentException("Invalid address");
        }

        c.setFirstName(firstName);
        c.setLastName(lastName);
        c.setPhone(phone);
        c.setAddress(address);
    }

    // Enhancement for CS 499 Milestone Three
    // Simple search algorithm that finds a contact by first name
    public Contact searchByFirstName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }

        for (Contact c : contacts.values()) {
            if (c.getFirstName().equalsIgnoreCase(name)) {
                return c;
            }
        }

        return null;
    }
}
