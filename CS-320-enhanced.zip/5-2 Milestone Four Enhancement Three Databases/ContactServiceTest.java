package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Tests for ContactService
public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void addContactSuccessfully() {
        Contact c = new Contact("1", "A", "B", "0123456789", "Addr");
        assertDoesNotThrow(() -> service.addContact(c));
    }

    @Test
    void addDuplicateIdThrows() {
        Contact c1 = new Contact("1", "A", "B", "0123456789", "Addr");
        Contact c2 = new Contact("1", "C", "D", "0987654321", "Addr2");

        service.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c2));
    }

    @Test
    void deleteContactRemovesEntry() {
        Contact c = new Contact("2", "X", "Y", "0123456789", "Addr");
        service.addContact(c);

        assertDoesNotThrow(() -> service.deleteContact("2"));
        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("2", "E", "F", "0987654321", "NewAddr"));
    }

    @Test
    void updateContactSuccessfully() {
        Contact c = new Contact("3", "M", "N", "0123456789", "OrigAddr");
        service.addContact(c);

        assertDoesNotThrow(() ->
                service.updateContact("3", "M2", "N2", "0987654321", "NewAddr"));

        assertEquals("M2", c.getFirstName());
        assertEquals("N2", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("NewAddr", c.getAddress());
    }

    @Test
    void updateNonexistentThrows() {
        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("nope", "A", "B", "0123456789", "Addr"));
    }

    // New test for CS 499 Milestone Three enhancement
    @Test
    void searchByFirstNameFindsContact() {
        Contact c = new Contact("10", "Alice", "Smith", "0123456789", "Addr");
        service.addContact(c);

        Contact result = service.searchByFirstName("Alice");

        assertNotNull(result);
        assertEquals("Alice", result.getFirstName());
    }
}
