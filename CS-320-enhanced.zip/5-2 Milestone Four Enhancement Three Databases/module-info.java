// Module file for CS320 project.
// Enhanced for CS 499 Milestone Two.

module CS320 {
}
